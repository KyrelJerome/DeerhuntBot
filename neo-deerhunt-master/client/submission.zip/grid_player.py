from helper_classes import *
class GridPlayer:

    def __init__(self):
        self.foo = True

    def tick(self, game_map, your_units, enemy_units, resources, turns_left):
        workers = your_units.get_all_unit_of_type('worker')
        melees = your_units.get_all_unit_of_type('melee')
        moves = []
        for worker in workers:
            if worker != None:  
                if worker.can_mine(game_map):
                    moves.append(worker.mine())
                else:
                    # move worker towards resource
                    resources = game_map.closest_resources(worker)
                    print("Turn:" + str(100 - turns_left))
                    print("Resources: " + str(resources))
                    worker_path = game_map.bfs(worker.position(),resources)
                    print("Goal: " + str(worker_path[0]))
                    move = worker.move_towards(worker_path[1])
                    #worker_path = None
                    print("Move" + str(move.to_tuple()))
                    moves.append(move)
       ''' for melee in melees:
            if melee != None:
                
                if melee.can_attack(game_map):
                    moves.append(melee.mine())
                else:
                    # move worker towards resource
                    resources = game_map.closest_resources(melee)
                    print("Turn:" + str(100 - turns_left))
                    print("Resources: " + str(resources))
                    melee_path = game_map.bfs(melee.position(),resources)
                    print("Goal: " + str(melee_path[0]))
                    move = melee.move_towards(melee_path[1])
                    #worker_path = None
                    print("Move" + str(move.to_tuple()))
                    moves.append(move)
        '''
        return moves
    #cd //mnt/c/d/Personal/Hackathons/neo_deerhunt_master/neo_deerhunt_master
