from helper_classes import *
class GridPlayer:

    def __init__(self):
        self.foo = True
 
    def pre_game_calc(self, game_map, your_units):
        workers = your_units.get_all_unit_of_type('worker')
        melees = your_units.get_all_unit_of_type('melee')
        num_workers = your_units.get_all_unit_of_type('worker')
        num_melees = your_units.get_all_unit_of_type('worker')
        
        resource_nodes = game_map.find_all_resources()
        column = len(game_map.grid[0])
        row = len(game_map.grid)
        print("MAP SIZE: {0} x {1}".format(column, row))

        enemy_distance = []
        for m in melees:
            enemy_coord = (abs(column - m.x), abs(row - m.y))
            enemy_distance.append(len(game_map.bfs(enemy_coord, resource_nodes[0])) - 1)
        self.set_safety(min(enemy_distance))

    def tick(self, game_map, your_units, enemy_units, resources, turns_left):
        protectDist =  4
        num_resources = resources
        workers = your_units.get_all_unit_of_type('worker')
        melees = your_units.get_all_unit_of_type('melee')
        num_workers = len(workers)
        num_soldiers = len(melees)
        moves = []
        
        unused_workers = []
        resource_to_workers = {}
        print("Num of enemies" + str(len(enemy_units.units)))
        for worker in workers:
            resource = game_map.closest_resources(worker)
            if resource in resource_to_workers:
                new_path = bfs(game_map, your_units, enemy_units, worker.position(),resource)
                current_path = bfs(game_map, your_units, enemy_units, resource_to_workers[resource].position(), resource)
                if len(new_path) < len(current_path):
                    unused_workers.append(resource_to_workers[resource])
                    resource_to_workers[resource] = worker
                else:
                    unused_workers.append(worker)
            else:                
                resource_to_workers[resource] = worker    
        
        for resource in resource_to_workers:
            worker = resource_to_workers[resource]
        
            print("Worker:" + str(worker.id))
            if worker.can_mine(game_map):
                print("Mining:" + str(worker.id))
                moves.append(worker.mine())
            else:
                # get resources
                print("Turn:" + str(100 - turns_left))
                # get path
                worker_path = bfs(game_map, your_units, enemy_units, worker.position(),resource)#.bfs(worker.position(), resource)
                if worker_path != None and len(worker_path) > 1:
                    print("Goal: " + str(worker_path[1]))
                    #move
                    if is_open(game_map, worker_path[1], your_units, enemy_units):
                        move = worker.move_towards(worker_path[1])
                        print("Move" + str(move.to_tuple()))
                        moves.append(move)
                else:
                    print("worker_path is None or 0")
        is_guarding =  False
        guarded = {}
        guardedL = {}
        for worker in workers:
            distance_pair =  worker.nearby_enemies_by_distance(your_units)
            print("Pairs for worker: " + str(worker.id))
            
            print(str(len(distance_pair)))
            print(distance_pair)
            for pair in distance_pair:
                if pair[1] < protectDist and your_units.get_unit(pair[0]).type == 'melee':
                    print("adding pair: " + str(pair))
                    if worker.id not in guarded.keys():
                        print("created list for worker")
                        guarded[worker.id] = [pair[0]]
                        guardedL[worker.id] = [pair[1]]
                    else:
                        
                        print("added to list for worker")
                        guarded[worker.id].append(pair[0])
                        guardedL[worker.id] = [pair[1]]
                    if len(guarded[worker.id])  > 3:
                        break
        attackers = []
        for melee in melees:
            if melee != None:
                isAttacking = False
                targets = melee.can_attack(enemy_units)
                print("")
                print("Melee at" + str(melee.position())+ ": " + str(melee.id))
                if len(targets) >= 1 :
                    target = targets[0][0]
                    print("Attacking: " + str(melee.id) + " to " +   str(target.id))
                    moves.append(melee.attack(melee.direction_to(target.position())))
                    isAttacking = True
                    attackers.append(melee)
                else:
                    enemies = melee.nearby_enemies_by_distance(enemy_units)
                    print("total enemies" + str(len(enemy_units.units)) + " , nearby enemies:" + str(len(enemies)) )
                    if len(enemies) >= 1:
                        attackers.append(melee)
                        isAttacking = True
                        enemy = enemy_units.get_unit(enemies[0][0])# enemies is a unit
                        print("enemy position: " + str(enemy.position()))
                        melee_path = bfs(game_map, your_units, enemy_units, melee.position(),enemy.position())
                        if melee_path != None and len(melee_path) > 2:
                            print("Next Position: " + str(melee_path[1]))
                            if is_open(game_map, melee_path[1], your_units, enemy_units):
                                move = melee.move_towards(melee_path[1])
                                print("Move" + str(move.to_tuple()))
                                moves.append(move)
                            else:
                                print("bfs sucks kyrel")
                        else:
                            print("Bruh that shit none!")
                    else:
                        
                        is_guarding = False
                        guarding = None
                        for key in guarded.keys():
                            print(str(key) + "guarded by:" + str(guarded[key]))
                            if str(melee.id) in guarded[key]:
                                print("Melee is guarding!")
                                is_guarding = True
                                guarding = your_units.get_unit(str(key))
                                break;
                        if is_guarding:
                            move = melee.move_towards(guarding.position())
                            moves.append(move)
                        elif len(melees) <  num_workers: #len(resources)*num_melees:
                            teammates = melee.nearby_enemies_by_distance(your_units)
                            if len(teammates) >= 1 and melee.can_duplicate(num_resources):
                                directions = []
                                for teammate in teammates:# find viable direction to teammates
                                    direction = melee.direction_to(your_units.get_unit(teammate[0]).position())
                                    if direction != None and (not direction in directions ):
                                        directions.append(direction)
                                for direction in ('UP', 'DOWN', 'LEFT', 'RIGHT'):
                                    if not (direction in directions):
                                        directions.append(direction)
                                print("directions: " + str(directions))
                                for direction in directions:
                                    print("direction" + str(direction))
                                    goal = coordinate_from_direction(melee.position()[0], melee.position()[1], direction)
                                    if goal == None:
                                      print("goal is none")
                                    if goal != None and is_open(game_map,goal, your_units, enemy_units):
                                        moves.append(melee.duplicate(direction))
                                        break;
                                    break;
        print("moves")
        for move in moves:
            print("move:" + str(move.to_tuple()))
        return moves

def is_open(game_map, position, your_units, enemy_units):
    for unit_id in your_units.get_all_unit_ids():
        if position == your_units.get_unit(unit_id).position():
            return False
    for unit_id in enemy_units.get_all_unit_ids():
        if position == enemy_units.get_unit(unit_id).position():
            return False
    return not game_map.is_wall(position[0], position[1])

def bfs(game_map, your_units, enemy_units, start: (int, int), dest: (int, int)) -> [(int, int)]:
    """(Map, (int, int), (int, int)) -> [(int, int)]
    Finds the shortest path from <start> to <dest>.
    Returns a path with a list of coordinates starting with
    <start> to <dest>.
    """
    graph = game_map.grid
    queue = [[start]]
    vis = set(start)
    if start == dest or graph[start[1]][start[0]] == 'X' or \
            not (0 < start[0] < len(graph[0])-1
                 and 0 < start[1] < len(graph)-1):
        return None

    while queue:
        path = queue.pop(0)
        node = path[-1]
        r = node[1]
        c = node[0]

        if node == dest:
            return path
        for adj in ((c+1, r), (c-1, r), (c, r+1), (c, r-1)):
            if (is_open(game_map, adj, your_units, enemy_units ) or
                    graph[adj[1]][adj[0]] == 'R') and adj not in vis:
                queue.append(path + [adj])
                vis.add(adj)
