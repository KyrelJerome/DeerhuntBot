from helper_classes import *
class GridPlayer:

    def __init__(self):
        self.foo = True

    def tick(self, game_map, your_units, enemy_units, resources, turns_left):
        workers = your_units.get_all_unit_of_type('worker')
        melees = your_units.get_all_unit_of_type('melee')
        moves = []
        print("Num of enemies" + str(len(enemy_units.units)))
        for worker in workers:
            if worker != None:
                print("Worker:" + str(worker.id))
                if worker.can_mine(game_map):
                    print("Mining:" + str(worker.id))
                    moves.append(worker.mine())
                else:
                    # move worker towards resource
                    resources = game_map.closest_resources(worker)
                    print("Turn:" + str(100 - turns_left))
                    print("Resources: " + str(resources))
                    worker_path = game_map.bfs(worker.position(),resources)
                    if worker_path != None and len(worker_path) > 1:
                        print("Goal: " + str(worker_path[1]))
                        if is_open(game_map, worker_path[1], your_units, enemy_units):
                            move = worker.move_towards(worker_path[1])
                            print("Move" + str(move.to_tuple()))
                            moves.append(move)
                    else:
                        print("Worker has no moves")
        for melee in melees:
            if melee != None:
                targets = melee.can_attack(enemy_units)
                print("")
                print("Melee at" + str(melee.position())+ ": " + str(melee.id))
                if len(targets) >= 1 :
                    target = targets[0][0]
                    print("Attacking: " + str(melee.id) + " to " +   str(target.id))
                    moves.append(melee.attack(melee.direction_to(target.position())))
                else:
                    # move worker towards resource
                    enemies = melee.nearby_enemies_by_distance(enemy_units)
                    print("total enemies" + str(len(enemy_units.units)) + " , nearby enemies:" + str(len(enemies)) )
                    if len(enemies) >= 1:
                        enemy = enemy_units.get_unit(enemies[0][0])# enemies is a unit
                        print("enemy position: " + str(enemy.position()))
                        melee_path = bfs(game_map, your_units, enemy_units, melee.position(),enemy.position())
                        if melee_path != None and len(melee_path) > 2:
                            print("Next Position: " + str(melee_path[1]))
                            if is_open(game_map, melee_path[1], your_units, enemy_units):
                                move = melee.move_towards(melee_path[1])
                                print("Move" + str(move.to_tuple()))
                                moves.append(move)
                            else:
                                print("bfs sucks kyrel")
                        else:
                            print("Bruh that shit none!")
                    else:
                        print("No enemies found!!")
        print("moves")
        for move in moves:
            print("move:" + str(move.to_tuple()))
        return moves

def is_open(game_map, position, your_units, enemy_units):
    for unit_id in your_units.get_all_unit_ids():
        if position == your_units.get_unit(unit_id).position():
            return False
    for unit_id in enemy_units.get_all_unit_ids():
        if position == enemy_units.get_unit(unit_id).position():
            return False
    return not game_map.is_wall(position[0], position[1])

def bfs(game_map, your_units, enemy_units, start: (int, int), dest: (int, int)) -> [(int, int)]:
    """(Map, (int, int), (int, int)) -> [(int, int)]
    Finds the shortest path from <start> to <dest>.
    Returns a path with a list of coordinates starting with
    <start> to <dest>.
    """
    graph = game_map.grid
    queue = [[start]]
    vis = set(start)
    if start == dest or graph[start[1]][start[0]] == 'X' or \
            not (0 < start[0] < len(graph[0])-1
                 and 0 < start[1] < len(graph)-1):
        return None

    while queue:
        path = queue.pop(0)
        node = path[-1]
        r = node[1]
        c = node[0]

        if node == dest:
            return path
        for adj in ((c+1, r), (c-1, r), (c, r+1), (c, r-1)):
            if (is_open(game_map, adj, your_units, enemy_units ) or
                    graph[adj[1]][adj[0]] == 'R') and adj not in vis:
                queue.append(path + [adj])
                vis.add(adj)


'''
for melee in melees:
            if melee != None:
                
                if melee.can_attack(game_map):
                    moves.append(melee.mine())
                else:
                    # move worker towards resource
                    resources = game_map.closest_resources(melee)
                    print("Trn:" + str(100 - turns_left))
                    print("Resources: " + str(resources))
                    melee_path = game_map.bfs(melee.position(),resources)
                    print("Goal: " + str(melee_path[0]))
                    move = melee.move_towards(melee_path[1])
                    #worker_path = None
                    print("Move" + str(move.to_tuple()))
                    moves.append(move)
'''
